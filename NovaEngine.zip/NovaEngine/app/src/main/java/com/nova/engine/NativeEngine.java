package com.nova.engine;

/** JNI bridge to the C++ engine core (engine.cpp). */
public class NativeEngine {
    static { System.loadLibrary("nova"); }
    public static native void init();
    public static native void resize(int w, int h);
    public static native void draw(float dt);
    public static native int add();
    public static native void remove();
    public static native void select(int i);
    public static native int count();
    public static native int selected();
    public static native float[] getTransform();   // px,py,pz, rx,ry,rz(deg), sx,sy,sz
    public static native void setTransform(float[] t);
    public static native void setColor(float r, float g, float b);
    public static native void orbit(float dx, float dy);
    public static native void zoom(float f);
    public static native void setPlaying(boolean on);
    public static native void setScript(String s);
    public static native String getScript();
    public static native int addModel(int mesh);
    public static native int loadModel(String name, String objText);   // returns mesh id or -1
    public static native int pick(float x, float y, int w, int h);      // tap-select, returns index or -1
    public static native void setDynamic(boolean on);
    public static native boolean isDynamic();
    public static native int pollSound();                               // type*1000 + volume%
    public static native String exportScene();
    public static native int importScene(String text);
}
