package com.nova.engine;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.*;
import java.io.*;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MainActivity extends Activity {
    static final int REQ_SAVE = 1, REQ_LOAD = 2, REQ_MODEL = 3;
    GLSurfaceView gl;
    SeekBar[] sb = new SeekBar[5];
    final String[] names = {"Pos X", "Pos Y", "Pos Z", "Rot Y", "Scale"};
    final float[] mn = {-8, -2, -8, 0, .2f}, mx = {8, 8, 8, 360, 4};
    boolean updating;
    EditText script, prompt, key;
    TextView hud, log;
    Button physBtn;
    String lastAi = "";
    SoundFx sfx;

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    Button btn(String t, int color, View.OnClickListener l) {
        Button b = new Button(this); b.setText(t); b.setAllCaps(false); b.setTextSize(12);
        b.setTextColor(Color.WHITE); b.setBackgroundColor(color); b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(38)); p.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(p); b.setPadding(dp(8), 0, dp(8), 0); return b;
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        sfx = new SoundFx(this);
        if (NativeEngine.count() == 0) {
            try { NativeEngine.importScene(readFile(new File(getFilesDir(), "autosave.nova"))); } catch (Exception ignored) {}
            if (NativeEngine.count() == 0) NativeEngine.add();
        }

        gl = new GLSurfaceView(this); gl.setEGLContextClientVersion(2);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            long t = System.nanoTime();
            public void onSurfaceCreated(GL10 g, EGLConfig c) { NativeEngine.init(); }
            public void onSurfaceChanged(GL10 g, int w, int h) { NativeEngine.resize(w, h); }
            public void onDrawFrame(GL10 g) {
                long n = System.nanoTime(); float dt = (n - t) / 1e9f; t = n;
                NativeEngine.draw(Math.min(dt, .05f));
                int e; while ((e = NativeEngine.pollSound()) != 0) sfx.play(e / 1000, (e % 1000) / 100f);
            }
        });
        final ScaleGestureDetector sg = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            public boolean onScale(ScaleGestureDetector d) { NativeEngine.zoom(d.getScaleFactor()); return true; }
        });
        final float[] last = {0, 0}, st = {0, 0}; // st[0]=moved distance, st[1]=multi-touch flag
        gl.setOnTouchListener((v, e) -> {
            sg.onTouchEvent(e);
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) { st[0] = 0; st[1] = 0; last[0] = e.getX(); last[1] = e.getY(); }
            if (e.getPointerCount() > 1) st[1] = 1;
            if (e.getPointerCount() == 1) {
                if (a == MotionEvent.ACTION_MOVE) {
                    float dx = e.getX() - last[0], dy = e.getY() - last[1];
                    NativeEngine.orbit(dx, dy); st[0] += Math.abs(dx) + Math.abs(dy);
                }
                last[0] = e.getX(); last[1] = e.getY();
            }
            if (a == MotionEvent.ACTION_UP && st[1] == 0 && st[0] < dp(12)) {   // TAP -> select object
                if (NativeEngine.pick(e.getX(), e.getY(), v.getWidth(), v.getHeight()) >= 0) refresh();
            }
            return true;
        });
        hud = new TextView(this); hud.setTextColor(Color.WHITE); hud.setPadding(dp(8), dp(4), 0, 0);
        FrameLayout view = new FrameLayout(this); view.addView(gl); view.addView(hud);

        LinearLayout bar = new LinearLayout(this); bar.setBackgroundColor(0xFF262932);
        bar.addView(btn("▶ Play", 0xFF2FBF71, v -> NativeEngine.setPlaying(true)));
        bar.addView(btn("■ Stop", 0xFFE5484D, v -> { NativeEngine.setPlaying(false); refresh(); }));
        bar.addView(btn("+ Cube", 0xFF4F8CFF, v -> { NativeEngine.add(); refresh(); }));
        bar.addView(btn("📦 Model", 0xFF4F8CFF, v -> pickFile(REQ_MODEL)));
        bar.addView(btn("🗑 Delete", 0xFF555A66, v -> { NativeEngine.remove(); refresh(); }));
        physBtn = btn("⚛ Physics: OFF", 0xFF8E5BD9, v -> { NativeEngine.setDynamic(!NativeEngine.isDynamic()); refresh(); });
        bar.addView(physBtn);
        bar.addView(btn("🔊 Test", 0xFF555A66, v -> sfx.play(2, 1f)));
        bar.addView(btn("💾 Save", 0xFFD9822B, v -> startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_TITLE, "scene.nova"), REQ_SAVE)));
        bar.addView(btn("📂 Load", 0xFFD9822B, v -> pickFile(REQ_LOAD)));
        bar.addView(btn("◀", 0xFF555A66, v -> { NativeEngine.select(NativeEngine.selected() - 1); refresh(); }));
        bar.addView(btn("▶", 0xFF555A66, v -> { NativeEngine.select(NativeEngine.selected() + 1); refresh(); }));
        bar.addView(btn("🎨", 0xFF555A66, v -> {
            int c = Color.HSVToColor(new float[]{(float) Math.random() * 360, .6f, .95f});
            NativeEngine.setColor(Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f);
        }));
        HorizontalScrollView barScroll = new HorizontalScrollView(this); barScroll.addView(bar);

        LinearLayout side = new LinearLayout(this); side.setOrientation(LinearLayout.VERTICAL); side.setPadding(dp(8), dp(4), dp(8), dp(4));
        side.addView(label("INSPECTOR  (tap an object in the viewport to select it)"));
        for (int i = 0; i < 5; i++) {
            side.addView(label(names[i]));
            sb[i] = new SeekBar(this); sb[i].setMax(1000);
            sb[i].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(SeekBar b, int p, boolean user) { if (user && !updating) push(); }
                public void onStartTrackingTouch(SeekBar b) {} public void onStopTrackingTouch(SeekBar b) {}
            });
            side.addView(sb[i]);
        }
        side.addView(label("SCRIPT: spin y 90 · move x 1 · bob 0.5 2 · pulse 0.2 3 · physics · static · sound hit · impulse y 8"));
        script = edit(4); side.addView(script);
        side.addView(btn("Save script", 0xFF4F8CFF, v -> NativeEngine.setScript(script.getText().toString())));
        side.addView(label("AI ASSISTANT (Groq)"));
        key = edit(1); key.setHint("Groq API key  gsk_..."); side.addView(key);
        prompt = edit(2); prompt.setHint("e.g. make it fall, bounce and beep"); side.addView(prompt);
        LinearLayout ai = new LinearLayout(this);
        ai.addView(btn("Ask AI", 0xFF4F8CFF, v -> askAi()));
        ai.addView(btn("Apply", 0xFF2FBF71, v -> { if (!lastAi.isEmpty()) { script.setText(lastAi); NativeEngine.setScript(lastAi); } }));
        side.addView(ai);
        log = new TextView(this); log.setTextColor(0xFFAAAAAA); log.setTextSize(11); side.addView(log);
        ScrollView sideScroll = new ScrollView(this); sideScroll.addView(side); sideScroll.setBackgroundColor(0xFF1B1D23);

        LinearLayout row = new LinearLayout(this);
        row.addView(view, new LinearLayout.LayoutParams(0, -1, 1));
        row.addView(sideScroll, new LinearLayout.LayoutParams(dp(260), -1));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.addView(barScroll, new LinearLayout.LayoutParams(-1, dp(46)));
        root.addView(row, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        refresh();
    }

    TextView label(String t) { TextView v = new TextView(this); v.setText(t); v.setTextColor(0xFF8A90A0); v.setTextSize(10); v.setPadding(0, dp(6), 0, 0); return v; }
    EditText edit(int lines) {
        EditText e = new EditText(this); e.setTextColor(Color.WHITE); e.setHintTextColor(0xFF777777);
        e.setTextSize(12); e.setMinLines(lines); e.setGravity(android.view.Gravity.TOP); return e;
    }

    void push() {
        float[] t = NativeEngine.getTransform(), v = new float[5];
        for (int i = 0; i < 5; i++) v[i] = mn[i] + sb[i].getProgress() / 1000f * (mx[i] - mn[i]);
        t[0] = v[0]; t[1] = v[1]; t[2] = v[2]; t[4] = v[3]; t[6] = t[7] = t[8] = v[4];
        NativeEngine.setTransform(t);
    }

    void refresh() {
        float[] t = NativeEngine.getTransform(), v = {t[0], t[1], t[2], t[4], t[6]};
        updating = true;
        for (int i = 0; i < 5; i++) sb[i].setProgress((int) ((v[i] - mn[i]) / (mx[i] - mn[i]) * 1000));
        updating = false;
        script.setText(NativeEngine.getScript());
        physBtn.setText(NativeEngine.isDynamic() ? "⚛ Physics: ON" : "⚛ Physics: OFF");
        hud.setText("Object " + (NativeEngine.selected() + 1) + " / " + NativeEngine.count());
    }

    void askAi() {
        String k = key.getText().toString().trim();
        if (k.isEmpty()) { log.setText("Paste your Groq key first"); return; }
        log.setText("Thinking...");
        GroqClient.ask(k, prompt.getText().toString(), new GroqClient.Callback() {
            public void ok(String text) { runOnUiThread(() -> { lastAi = text; log.setText(text); }); }
            public void err(String m) { runOnUiThread(() -> log.setText("AI error: " + m)); }
        });
    }

    // ---------- files: models (.obj), scenes (.nova) ----------
    void pickFile(int req) { startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), req); }

    static String readStream(InputStream in) throws IOException {
        ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        in.close(); return o.toString("UTF-8");
    }
    static String readFile(File f) throws IOException { return readStream(new FileInputStream(f)); }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            if (req == REQ_SAVE) {
                OutputStream o = getContentResolver().openOutputStream(u);
                o.write(NativeEngine.exportScene().getBytes("UTF-8")); o.close(); log.setText("Scene saved");
            } else if (req == REQ_LOAD) {
                int n = NativeEngine.importScene(readStream(getContentResolver().openInputStream(u)));
                log.setText("Loaded " + n + " objects"); refresh();
            } else if (req == REQ_MODEL) {
                String name = String.valueOf(u.getLastPathSegment()).replaceAll("[^A-Za-z0-9._-]", "_");
                int mesh = NativeEngine.loadModel(name, readStream(getContentResolver().openInputStream(u)));
                if (mesh < 0) log.setText("Could not read that model (needs .obj with faces)");
                else { NativeEngine.addModel(mesh); log.setText("Model loaded: " + name); refresh(); }
            }
        } catch (Exception e) { log.setText("File error: " + e); }
    }

    @Override protected void onPause() {
        super.onPause(); gl.onPause();
        try (FileOutputStream o = new FileOutputStream(new File(getFilesDir(), "autosave.nova"))) {
            o.write(NativeEngine.exportScene().getBytes("UTF-8"));
        } catch (Exception ignored) {}
    }
    @Override protected void onResume() { super.onResume(); gl.onResume(); }
    @Override protected void onDestroy() { super.onDestroy(); sfx.release(); }
}
