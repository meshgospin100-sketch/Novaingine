package com.nova.engine;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Random;

/** Procedural sound effects (no asset files): 1=hit, 2=beep, 3=pop. */
public class SoundFx {
    private final SoundPool pool;
    private final int[] ids = new int[4];

    public SoundFx(Context c) {
        pool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()).build();
        try { for (int i = 1; i <= 3; i++) ids[i] = load(c, "fx" + i, gen(i)); } catch (IOException ignored) {}
    }

    static short[] gen(int type) {
        int sr = 22050, n = (int) (sr * (type == 1 ? .25 : type == 2 ? .2 : .15));
        short[] s = new short[n]; Random r = new Random(7); double ph = 0;
        for (int i = 0; i < n; i++) {
            double t = i / (double) sr, v;
            if (type == 1) v = (r.nextDouble() * 2 - 1) * Math.exp(-t * 25) * .6 + Math.sin(2 * Math.PI * 90 * t) * Math.exp(-t * 10);
            else if (type == 2) v = Math.sin(2 * Math.PI * 880 * t) * Math.exp(-t * 12);
            else { ph += 2 * Math.PI * (600 - 400 * (t / .15)) / sr; v = Math.sin(ph) * Math.exp(-t * 15); }
            s[i] = (short) (Math.max(-1, Math.min(1, v)) * 20000);
        }
        return s;
    }

    private int load(Context c, String name, short[] pcm) throws IOException {
        File f = new File(c.getCacheDir(), name + ".wav");
        ByteBuffer b = ByteBuffer.allocate(44 + pcm.length * 2).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes()).putInt(36 + pcm.length * 2).put("WAVEfmt ".getBytes()).putInt(16)
         .putShort((short) 1).putShort((short) 1).putInt(22050).putInt(22050 * 2).putShort((short) 2).putShort((short) 16)
         .put("data".getBytes()).putInt(pcm.length * 2);
        for (short x : pcm) b.putShort(x);
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(b.array()); }
        return pool.load(f.getPath(), 1);
    }

    public void play(int id, float vol) { if (id > 0 && id < 4 && ids[id] != 0) pool.play(ids[id], vol, vol, 1, 0, 1f); }
    public void release() { pool.release(); }
}
