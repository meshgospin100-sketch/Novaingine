package com.nova.engine;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

/** Calls the Groq chat API and returns engine script text. */
public class GroqClient {
    public interface Callback { void ok(String text); void err(String msg); }

    static final String SYSTEM =
        "You write scripts for a game engine. Reply with ONLY script lines, no markdown. Allowed lines:\n"
      + "spin <x|y|z> <degrees per second>\nmove <x|y|z> <units per second>\n"
      + "bob <amplitude> <speed>\npulse <amplitude> <speed>\n"
      + "physics\nstatic\nsound <hit|beep|pop>\nimpulse <x|y|z> <force>";

    public static void ask(final String key, final String prompt, final Callback cb) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("https://api.groq.com/openai/v1/chat/completions").openConnection();
                c.setRequestMethod("POST");
                c.setRequestProperty("Content-Type", "application/json");
                c.setRequestProperty("Authorization", "Bearer " + key);
                c.setDoOutput(true);
                JSONArray msgs = new JSONArray()
                    .put(new JSONObject().put("role", "system").put("content", SYSTEM))
                    .put(new JSONObject().put("role", "user").put("content", prompt));
                JSONObject body = new JSONObject().put("model", "llama-3.3-70b-versatile").put("messages", msgs);
                c.getOutputStream().write(body.toString().getBytes("UTF-8"));
                int code = c.getResponseCode();
                InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
                String txt = new Scanner(in, "UTF-8").useDelimiter("\\A").next();
                if (code >= 400) { cb.err("HTTP " + code + ": " + txt); return; }
                String out = new JSONObject(txt).getJSONArray("choices").getJSONObject(0)
                        .getJSONObject("message").getString("content");
                cb.ok(out.replaceAll("```\\w*", "").trim());
            } catch (Exception e) { cb.err(String.valueOf(e)); }
        }).start();
    }
}
