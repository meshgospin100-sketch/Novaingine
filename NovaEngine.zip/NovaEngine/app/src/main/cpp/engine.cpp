// Nova Engine core (C++): scene, renderer, physics, OBJ loader, scene save/load, script VM.
#include <jni.h>
#include <GLES2/gl2.h>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

struct Mesh { string name, src; vector<float> verts; float he[3] = {.5f, .5f, .5f}; };
struct Cmd { int type; int axis; float a, b; };  // 0 spin 1 move 2 bob 3 pulse 4 physics/static 5 sound 6 impulse
struct Obj {
    float p[3] = {0, .5f, 0}, r[3] = {0, 0, 0}, s[3] = {1, 1, 1}, c[3] = {.31f, .55f, 1};
    float sp[3], sr[3], ss[3], v[3] = {0, 0, 0}; float t = 0; bool dyn = false; int mesh = -1;
    string src; vector<Cmd> cmds;
};
static vector<Obj> objs; static vector<Mesh> meshes; static vector<int> evq;
static int sel = -1; static bool playing = false; static mutex mu;
static float th = .8f, ph = 1.1f, rad = 9, asp = 1.7f; static const float FOV = 1.05f;
static GLuint prog; static GLint aP, aN, uMVP, uM, uC; static vector<float> cube, grid;

// ---------- math (column-major 4x4) ----------
static void ident(float* m) { for (int i = 0; i < 16; i++) m[i] = (i % 5 == 0); }
static void mul(const float* a, const float* b, float* o) {
    float t[16];
    for (int c = 0; c < 4; c++) for (int r = 0; r < 4; r++) {
        t[c * 4 + r] = 0; for (int k = 0; k < 4; k++) t[c * 4 + r] += a[k * 4 + r] * b[c * 4 + k];
    }
    memcpy(o, t, 64);
}
static void rotX(float d, float* m) { float a = d * M_PI / 180, c = cosf(a), s = sinf(a); ident(m); m[5] = c; m[6] = s; m[9] = -s; m[10] = c; }
static void rotY(float d, float* m) { float a = d * M_PI / 180, c = cosf(a), s = sinf(a); ident(m); m[0] = c; m[8] = s; m[2] = -s; m[10] = c; }
static void rotZ(float d, float* m) { float a = d * M_PI / 180, c = cosf(a), s = sinf(a); ident(m); m[0] = c; m[4] = -s; m[1] = s; m[5] = c; }
static void modelMat(const Obj& o, float* m) {
    float t[16], rx[16], ry[16], rz[16], sc[16], a[16];
    ident(t); t[12] = o.p[0]; t[13] = o.p[1]; t[14] = o.p[2];
    ident(sc); sc[0] = o.s[0]; sc[5] = o.s[1]; sc[10] = o.s[2];
    rotX(o.r[0], rx); rotY(o.r[1], ry); rotZ(o.r[2], rz);
    mul(t, rz, a); mul(a, ry, a); mul(a, rx, a); mul(a, sc, m);
}
static void persp(float fov, float asp_, float n, float f, float* m) {
    float k = 1.f / tanf(fov * .5f); memset(m, 0, 64);
    m[0] = k / asp_; m[5] = k; m[10] = (f + n) / (n - f); m[11] = -1; m[14] = 2 * f * n / (n - f);
}
// camera basis: eye, forward f, right s, up v
static void camBasis(float* e, float* f, float* s, float* v) {
    e[0] = rad * sinf(ph) * cosf(th); e[1] = .5f + rad * cosf(ph); e[2] = rad * sinf(ph) * sinf(th);
    float tg[3] = {0, .5f, 0}; float l = 0;
    for (int i = 0; i < 3; i++) { f[i] = tg[i] - e[i]; l += f[i] * f[i]; }
    l = sqrtf(l); for (int i = 0; i < 3; i++) f[i] /= l;
    s[0] = -f[2]; s[1] = 0; s[2] = f[0]; l = sqrtf(s[0] * s[0] + s[2] * s[2]); s[0] /= l; s[2] /= l;
    v[0] = s[1] * f[2] - s[2] * f[1]; v[1] = s[2] * f[0] - s[0] * f[2]; v[2] = s[0] * f[1] - s[1] * f[0];
}
static void viewMat(float* m) {
    float e[3], f[3], s[3], v[3]; camBasis(e, f, s, v);
    float r[16] = {s[0], v[0], -f[0], 0, s[1], v[1], -f[1], 0, s[2], v[2], -f[2], 0,
                   -(s[0] * e[0] + s[1] * e[1] + s[2] * e[2]), -(v[0] * e[0] + v[1] * e[1] + v[2] * e[2]),
                   (f[0] * e[0] + f[1] * e[1] + f[2] * e[2]), 1};
    memcpy(m, r, 64);
}

// ---------- helpers ----------
static void ev(int type, float vol) { if (evq.size() < 16) evq.push_back(type * 1000 + (int)(fminf(1.f, fmaxf(.1f, vol)) * 100)); }
static void getHE(const Obj& o, float* h) {
    float b[3] = {.5f, .5f, .5f}; if (o.mesh >= 0 && o.mesh < (int)meshes.size()) memcpy(b, meshes[o.mesh].he, 12);
    for (int i = 0; i < 3; i++) h[i] = b[i] * fabsf(o.s[i]);
}
static bool rayBox(const float* o, const float* d, const float* c, const float* h, float& tt) {
    float t0 = 0, t1 = 1e9f;
    for (int i = 0; i < 3; i++) {
        float lo = c[i] - h[i] - o[i], hi = c[i] + h[i] - o[i];
        if (fabsf(d[i]) < 1e-6f) { if (lo > 0 || hi < 0) return false; }
        else { float a = lo / d[i], b = hi / d[i]; if (a > b) swap(a, b); t0 = fmaxf(t0, a); t1 = fminf(t1, b); if (t0 > t1) return false; }
    }
    tt = t0; return true;
}

// ---------- script VM ----------
// spin <x|y|z> <deg/s> | move <x|y|z> <u/s> | bob <amp> <speed> | pulse <amp> <speed>
// physics | static | sound <hit|beep|pop> | impulse <x|y|z> <force>
static int axisOf(const string& a) { return a == "x" ? 0 : a == "y" ? 1 : 2; }
static void parse(Obj& o) {
    o.cmds.clear(); istringstream in(o.src); string line;
    while (getline(in, line)) {
        istringstream ls(line); string w; if (!(ls >> w)) continue; Cmd c{-1, 0, 0, 0};
        if (w == "spin" || w == "move" || w == "impulse") {
            string ax; float a; if (!(ls >> ax >> a)) continue;
            c.type = w == "spin" ? 0 : w == "move" ? 1 : 6; c.axis = axisOf(ax); c.a = a;
        } else if (w == "bob" || w == "pulse") {
            float a, b; if (!(ls >> a >> b)) continue; c.type = w == "bob" ? 2 : 3; c.a = a; c.b = b;
        } else if (w == "physics" || w == "static") { c.type = 4; c.a = (w == "physics") ? 1.f : 0.f; }
        else if (w == "sound") { string n; ls >> n; c.type = 5; c.a = n == "hit" ? 1.f : n == "beep" ? 2.f : 3.f; }
        else continue;
        o.cmds.push_back(c);
    }
}
static void runScripts(float dt) {
    for (auto& o : objs) {
        o.t += dt;
        for (auto& c : o.cmds) switch (c.type) {
            case 0: o.r[c.axis] += c.a * dt; break;
            case 1: o.p[c.axis] += c.a * dt; break;
            case 2: o.p[1] = o.sp[1] + c.a * sinf(o.t * c.b); break;
            case 3: { float f = 1 + c.a * sinf(o.t * c.b); for (int i = 0; i < 3; i++) o.s[i] = o.ss[i] * f; break; }
            default: break;
        }
    }
}

// ---------- physics (AABB, gravity, floor at y=0, impulse resolution) ----------
static void physicsStep(float dt) {
    const float G = -9.8f;
    for (auto& o : objs) {
        if (!o.dyn) continue;
        o.v[1] += G * dt; for (int i = 0; i < 3; i++) o.p[i] += o.v[i] * dt;
        float h[3]; getHE(o, h);
        if (o.p[1] - h[1] < 0) {
            o.p[1] = h[1]; if (o.v[1] < -1.5f) ev(1, -o.v[1] / 10);
            o.v[1] = o.v[1] < -.5f ? -o.v[1] * .35f : 0; o.v[0] *= .97f; o.v[2] *= .97f;
        }
    }
    for (size_t i = 0; i < objs.size(); i++) for (size_t j = i + 1; j < objs.size(); j++) {
        Obj& a = objs[i]; Obj& b = objs[j]; if (!a.dyn && !b.dyn) continue;
        float ha[3], hb[3]; getHE(a, ha); getHE(b, hb);
        int ax = -1; float best = 1e9f; bool hit = true;
        for (int k = 0; k < 3; k++) {
            float pen = ha[k] + hb[k] - fabsf(b.p[k] - a.p[k]);
            if (pen <= 0) { hit = false; break; } if (pen < best) { best = pen; ax = k; }
        }
        if (!hit) continue;
        float sgn = (b.p[ax] - a.p[ax]) >= 0 ? 1.f : -1.f, ia = a.dyn ? 1.f : 0.f, ib = b.dyn ? 1.f : 0.f, tot = ia + ib;
        a.p[ax] -= sgn * best * ia / tot; b.p[ax] += sgn * best * ib / tot;
        float vn = (a.v[ax] - b.v[ax]) * sgn;
        if (vn > 0) { float imp = 1.3f * vn / tot; a.v[ax] -= sgn * imp * ia; b.v[ax] += sgn * imp * ib; if (vn > 1.5f) ev(1, vn / 10); }
    }
}

// ---------- OBJ model loader (v + f, fan triangulation, flat normals, normalised to unit size) ----------
static int loadMesh(const string& name, const string& text) {
    vector<float> vs; Mesh m; m.name = name; m.src = text;
    istringstream in(text); string line;
    while (getline(in, line)) {
        if (line.size() < 3) continue;
        if (line[0] == 'v' && line[1] == ' ') { float x, y, z; if (sscanf(line.c_str() + 2, "%f %f %f", &x, &y, &z) == 3) { vs.push_back(x); vs.push_back(y); vs.push_back(z); } }
        else if (line[0] == 'f' && line[1] == ' ') {
            istringstream ls(line.substr(2)); string tok; vector<int> id; int nv = (int)vs.size() / 3;
            while (ls >> tok) { int k = atoi(tok.c_str()); if (k < 0) k = nv + k + 1; if (k >= 1 && k <= nv) id.push_back(k - 1); }
            for (size_t t = 1; t + 1 < id.size(); t++) {
                const float *A = &vs[id[0] * 3], *B = &vs[id[t] * 3], *C = &vs[id[t + 1] * 3];
                float u[3], w[3], n[3];
                for (int i = 0; i < 3; i++) { u[i] = B[i] - A[i]; w[i] = C[i] - A[i]; }
                n[0] = u[1] * w[2] - u[2] * w[1]; n[1] = u[2] * w[0] - u[0] * w[2]; n[2] = u[0] * w[1] - u[1] * w[0];
                float l = sqrtf(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]); if (l < 1e-9f) continue;
                for (int i = 0; i < 3; i++) n[i] /= l;
                for (const float* P : {A, B, C}) { for (int i = 0; i < 3; i++) m.verts.push_back(P[i]); for (int i = 0; i < 3; i++) m.verts.push_back(n[i]); }
            }
        }
    }
    if (m.verts.empty()) return -1;
    float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f};
    for (size_t i = 0; i < m.verts.size(); i += 6) for (int k = 0; k < 3; k++) { mn[k] = fminf(mn[k], m.verts[i + k]); mx[k] = fmaxf(mx[k], m.verts[i + k]); }
    float dim = fmaxf(mx[0] - mn[0], fmaxf(mx[1] - mn[1], mx[2] - mn[2])); if (dim < 1e-9f) return -1;
    for (size_t i = 0; i < m.verts.size(); i += 6) for (int k = 0; k < 3; k++) m.verts[i + k] = (m.verts[i + k] - (mn[k] + mx[k]) / 2) / dim;
    for (int k = 0; k < 3; k++) m.he[k] = (mx[k] - mn[k]) / dim / 2;
    meshes.push_back(m); return (int)meshes.size() - 1;
}

// ---------- scene save / load ----------
static string exportScene() {
    ostringstream o; o << "NOVA1\n";
    for (auto& m : meshes) { o << "#MESH " << m.name << "\n" << m.src; if (m.src.empty() || m.src.back() != '\n') o << "\n"; o << "#ENDMESH\n"; }
    for (auto& b : objs) {
        string sc = b.src; for (char& c : sc) if (c == '\n' || c == '\r') c = ';';
        o << "obj " << b.mesh; for (int i = 0; i < 3; i++) o << " " << b.p[i]; for (int i = 0; i < 3; i++) o << " " << b.r[i];
        for (int i = 0; i < 3; i++) o << " " << b.s[i]; for (int i = 0; i < 3; i++) o << " " << b.c[i];
        o << " " << (int)b.dyn << " " << sc << "\n";
    }
    return o.str();
}
static int importScene(const string& text) {
    objs.clear(); meshes.clear(); sel = -1; playing = false;
    istringstream in(text); string line, name, cur; bool inMesh = false;
    while (getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (inMesh) { if (line == "#ENDMESH") { loadMesh(name, cur); inMesh = false; } else cur += line + "\n"; continue; }
        if (line.rfind("#MESH", 0) == 0) { inMesh = true; cur.clear(); name = line.size() > 6 ? line.substr(6) : "model"; continue; }
        if (line.rfind("obj ", 0) == 0) {
            istringstream ls(line.substr(4)); Obj o; int d = 0;
            ls >> o.mesh; for (int i = 0; i < 3; i++) ls >> o.p[i]; for (int i = 0; i < 3; i++) ls >> o.r[i];
            for (int i = 0; i < 3; i++) ls >> o.s[i]; for (int i = 0; i < 3; i++) ls >> o.c[i]; ls >> d; o.dyn = d != 0;
            string rest; getline(ls, rest); if (!rest.empty() && rest[0] == ' ') rest.erase(0, 1);
            for (char& c : rest) if (c == ';') c = '\n'; o.src = rest; parse(o);
            if (o.mesh >= (int)meshes.size()) o.mesh = -1; objs.push_back(o);
        }
    }
    sel = objs.empty() ? -1 : 0; return (int)objs.size();
}

// ---------- GL ----------
static GLuint sh(GLenum t, const char* s) { GLuint h = glCreateShader(t); glShaderSource(h, 1, &s, 0); glCompileShader(h); return h; }
static void buildMeshes() {
    cube.clear(); grid.clear();
    float cs[4][2] = {{-.5f, -.5f}, {.5f, -.5f}, {.5f, .5f}, {-.5f, .5f}}; int idx[6] = {0, 1, 2, 0, 2, 3};
    for (int a = 0; a < 3; a++) for (int sg = -1; sg <= 1; sg += 2) {
        int u = (a + 1) % 3, v = (a + 2) % 3; float n[3] = {0, 0, 0}; n[a] = (float)sg;
        for (int k = 0; k < 6; k++) {
            float q[3]; q[a] = sg * .5f; q[u] = cs[idx[k]][0]; q[v] = cs[idx[k]][1];
            for (int i = 0; i < 3; i++) cube.push_back(q[i]); for (int i = 0; i < 3; i++) cube.push_back(n[i]);
        }
    }
    for (int i = -10; i <= 10; i++) {
        float f = (float)i, L[4][6] = {{f, 0, -10, 0, 1, 0}, {f, 0, 10, 0, 1, 0}, {-10, 0, f, 0, 1, 0}, {10, 0, f, 0, 1, 0}};
        for (auto& r : L) for (float x : r) grid.push_back(x);
    }
}
static void drawMesh(vector<float>& v, GLenum mode, const float* mvp, const float* model, const float* col) {
    glUniformMatrix4fv(uMVP, 1, GL_FALSE, mvp); glUniformMatrix4fv(uM, 1, GL_FALSE, model); glUniform3fv(uC, 1, col);
    glVertexAttribPointer(aP, 3, GL_FLOAT, GL_FALSE, 24, v.data()); glVertexAttribPointer(aN, 3, GL_FLOAT, GL_FALSE, 24, v.data() + 3);
    glDrawArrays(mode, 0, (GLsizei)(v.size() / 6));
}

#define J(ret, name, ...) extern "C" JNIEXPORT ret JNICALL Java_com_nova_engine_NativeEngine_##name(JNIEnv* env, jclass, ##__VA_ARGS__)
#define LOCK lock_guard<mutex> lk_(mu)
static string jstr(JNIEnv* e, jstring s) { const char* c = e->GetStringUTFChars(s, 0); string r = c; e->ReleaseStringUTFChars(s, c); return r; }

J(void, init) {
    LOCK; buildMeshes(); prog = glCreateProgram();
    glAttachShader(prog, sh(GL_VERTEX_SHADER, "attribute vec3 aP;attribute vec3 aN;uniform mat4 uMVP,uM;varying vec3 vN;"
        "void main(){vN=(uM*vec4(aN,0.)).xyz;gl_Position=uMVP*vec4(aP,1.);}"));
    glAttachShader(prog, sh(GL_FRAGMENT_SHADER, "precision mediump float;varying vec3 vN;uniform vec3 uC;"
        "void main(){float d=max(dot(normalize(vN),normalize(vec3(.4,.9,.5))),0.);gl_FragColor=vec4(uC*(.35+.75*d),1.);}"));
    glLinkProgram(prog);
    aP = glGetAttribLocation(prog, "aP"); aN = glGetAttribLocation(prog, "aN");
    uMVP = glGetUniformLocation(prog, "uMVP"); uM = glGetUniformLocation(prog, "uM"); uC = glGetUniformLocation(prog, "uC");
}
J(void, resize, jint w, jint h) { LOCK; glViewport(0, 0, w, h); asp = (float)w / (float)(h ? h : 1); }
J(void, draw, jfloat dt) {
    LOCK;
    glClearColor(.08f, .09f, .11f, 1); glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); glEnable(GL_DEPTH_TEST);
    glUseProgram(prog); glEnableVertexAttribArray(aP); glEnableVertexAttribArray(aN);
    if (playing) { runScripts(dt); physicsStep(dt * .5f); physicsStep(dt * .5f); }
    float pr[16], vw[16], vp[16], id[16]; ident(id);
    persp(FOV, asp, .1f, 200, pr); viewMat(vw); mul(pr, vw, vp);
    float gc[3] = {.3f, .32f, .38f}; drawMesh(grid, GL_LINES, vp, id, gc);
    for (size_t i = 0; i < objs.size(); i++) {
        Obj& o = objs[i]; float m[16], mvp[16], col[3]; modelMat(o, m); mul(vp, m, mvp);
        bool s = ((int)i == sel && !playing);
        for (int k = 0; k < 3; k++) col[k] = fminf(1.f, o.c[k] + (s ? .35f : 0));
        drawMesh((o.mesh >= 0 && o.mesh < (int)meshes.size()) ? meshes[o.mesh].verts : cube, GL_TRIANGLES, mvp, m, col);
    }
}
J(jint, add) { LOCK; Obj o; o.p[0] = (float)(objs.size() % 5) * 1.5f - 3; objs.push_back(o); sel = (int)objs.size() - 1; return sel; }
J(jint, addModel, jint mesh) {
    LOCK; Obj o; o.mesh = mesh; o.p[1] = 1.f; o.p[0] = (float)(objs.size() % 5) * 1.5f - 3; o.c[0] = o.c[1] = o.c[2] = .8f;
    objs.push_back(o); sel = (int)objs.size() - 1; return sel;
}
J(jint, loadModel, jstring name, jstring text) { string n = jstr(env, name), t = jstr(env, text); LOCK; return loadMesh(n, t); }
J(void, remove) { LOCK; if (sel >= 0 && sel < (int)objs.size()) { objs.erase(objs.begin() + sel); sel = objs.empty() ? -1 : 0; } }
J(void, select, jint i) { LOCK; if (!objs.empty()) sel = ((i % (int)objs.size()) + (int)objs.size()) % (int)objs.size(); }
J(jint, count) { LOCK; return (jint)objs.size(); }
J(jint, selected) { LOCK; return sel; }
J(jint, pick, jfloat x, jfloat y, jint w, jint h) {
    LOCK; float e[3], f[3], s[3], v[3]; camBasis(e, f, s, v);
    float nx = 2 * x / w - 1, ny = 1 - 2 * y / h, k = tanf(FOV * .5f), d[3]; float best = 1e9f; int hit = -1;
    for (int i = 0; i < 3; i++) d[i] = f[i] + s[i] * nx * k * asp + v[i] * ny * k;
    for (size_t i = 0; i < objs.size(); i++) {
        float hh[3], tt; getHE(objs[i], hh);
        if (rayBox(e, d, objs[i].p, hh, tt) && tt < best) { best = tt; hit = (int)i; }
    }
    if (hit >= 0) sel = hit; return hit;
}
J(jfloatArray, getTransform) {
    LOCK; jfloatArray a = env->NewFloatArray(9); float t[9] = {0, 0, 0, 0, 0, 0, 1, 1, 1};
    if (sel >= 0) { memcpy(t, objs[sel].p, 12); memcpy(t + 3, objs[sel].r, 12); memcpy(t + 6, objs[sel].s, 12); }
    env->SetFloatArrayRegion(a, 0, 9, t); return a;
}
J(void, setTransform, jfloatArray a) {
    LOCK; if (sel < 0) return; float t[9]; env->GetFloatArrayRegion(a, 0, 9, t);
    memcpy(objs[sel].p, t, 12); memcpy(objs[sel].r, t + 3, 12); memcpy(objs[sel].s, t + 6, 12);
}
J(void, setColor, jfloat r, jfloat g, jfloat b) { LOCK; if (sel >= 0) { objs[sel].c[0] = r; objs[sel].c[1] = g; objs[sel].c[2] = b; } }
J(void, setDynamic, jboolean on) { LOCK; if (sel >= 0) objs[sel].dyn = on; }
J(jboolean, isDynamic) { LOCK; return sel >= 0 && objs[sel].dyn; }
J(void, orbit, jfloat dx, jfloat dy) { LOCK; th -= dx * .008f; ph = fminf(2.9f, fmaxf(.15f, ph - dy * .008f)); }
J(void, zoom, jfloat f) { LOCK; rad = fminf(40.f, fmaxf(3.f, rad / f)); }
J(void, setPlaying, jboolean on) {
    LOCK; if ((bool)on == playing) return; playing = on;
    for (auto& o : objs) {
        if (on) {
            memcpy(o.sp, o.p, 12); memcpy(o.sr, o.r, 12); memcpy(o.ss, o.s, 12); o.t = 0; memset(o.v, 0, 12);
            for (auto& c : o.cmds) { if (c.type == 4) o.dyn = c.a > 0; }
            for (auto& c : o.cmds) { if (c.type == 5) ev((int)c.a, .8f); if (c.type == 6) o.v[c.axis] += c.a; }
        } else { memcpy(o.p, o.sp, 12); memcpy(o.r, o.sr, 12); memcpy(o.s, o.ss, 12); memset(o.v, 0, 12); }
    }
}
J(void, setScript, jstring s) { string t = jstr(env, s); LOCK; if (sel < 0) return; objs[sel].src = t; parse(objs[sel]); }
J(jstring, getScript) { LOCK; return env->NewStringUTF(sel >= 0 ? objs[sel].src.c_str() : ""); }
J(jint, pollSound) { LOCK; if (evq.empty()) return 0; int e = evq.front(); evq.erase(evq.begin()); return e; }
J(jstring, exportScene) { LOCK; return env->NewStringUTF(exportScene().c_str()); }
J(jint, importScene, jstring s) { string t = jstr(env, s); LOCK; return importScene(t); }
